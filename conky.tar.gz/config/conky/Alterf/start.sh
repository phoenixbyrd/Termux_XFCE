#!/bin/bash

killall conky
sleep 2s
		
GALLIUM_DRIVER=virvpipe conky -c .config/conky/Alterf/Alterf.conf &> /dev/null &

exit
